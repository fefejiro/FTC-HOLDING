import React from 'react';

const ServicesPage = () => {
    return (
        <div>
            <h1>Our Services</h1>
            <p>At Fejiro Technology Consultancy Inc., we offer a range of services designed to meet the diverse needs of our clients. Below are the key areas of our expertise:</p>
            <ul>
                <li>
                    <a href="/services/enterprise-systems-infrastructure">Enterprise Systems & Infrastructure Consulting</a>
                </li>
                <li>
                    <a href="/services/intelligent-systems-automation">Intelligent Systems & Automation Engineering</a>
                </li>
                <li>
                    <a href="/services/product-technical-architecture">Product & Technical Architecture Advisory</a>
                </li>
            </ul>
            <p>For more information on each service, please click on the links above.</p>
        </div>
    );
};

export default ServicesPage;