import React from 'react';

const AboutPage = () => {
    return (
        <div>
            <h1>About Fejiro Technology Consultancy Inc.</h1>
            <section>
                <h2>Company Overview</h2>
                <p>Fejiro Technology Consultancy Inc. is a founder-led consultancy firm specializing in enterprise delivery and technology solutions.</p>
            </section>
            <section>
                <h2>Vision</h2>
                <p>Our vision is to empower businesses through innovative technology solutions that drive efficiency and growth.</p>
            </section>
            <section>
                <h2>Values</h2>
                <ul>
                    <li>Integrity</li>
                    <li>Innovation</li>
                    <li>Collaboration</li>
                    <li>Excellence</li>
                </ul>
            </section>
            <section>
                <h2>Applied Artificial Intelligence</h2>
                <p>We leverage applied AI to enhance our consulting services, ensuring our clients stay ahead in a rapidly evolving technological landscape.</p>
            </section>
        </div>
    );
};

export default AboutPage;