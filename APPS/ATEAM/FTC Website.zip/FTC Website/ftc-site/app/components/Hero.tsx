import React from 'react';

const Hero: React.FC = () => {
    return (
        <section className="hero">
            <div className="hero-content">
                <h1>Welcome to Fejiro Technology Consultancy Inc.</h1>
                <p>Your partner in innovative technology solutions.</p>
            </div>
        </section>
    );
};

export default Hero;