import React from 'react';
import Hero from './components/Hero';
import OverviewCards from './components/OverviewCards';
import CredibilityStrip from './components/CredibilityStrip';
import DifferentiatorSection from './components/DifferentiatorSection';
import CallToAction from './components/CallToAction';

const HomePage = () => {
    return (
        <main>
            <Hero />
            <section>
                <h2>Welcome to Fejiro Technology Consultancy Inc.</h2>
                <p>Your partner in innovative technology solutions.</p>
            </section>
            <OverviewCards />
            <CredibilityStrip />
            <DifferentiatorSection />
            <CallToAction />
        </main>
    );
};

export default HomePage;