import React from 'react';
import Header from '../components/Header';
import Footer from '../components/Footer';

const ContactPage = () => {
    return (
        <div>
            <Header />
            <main>
                <h1>Contact Us</h1>
                <p>If you have any questions or would like to schedule a consultation, please reach out to us.</p>
                <h2>Contact Method</h2>
                <p>Email: <a href="mailto:info@fejirotech.com">info@fejirotech.com</a></p>
                <h2>Schedule a Consultation</h2>
                <p>Click the button below to schedule a consultation with our team.</p>
                <button onClick={() => alert('Consultation scheduling feature coming soon!')}>Schedule Consultation</button>
            </main>
            <Footer />
        </div>
    );
};

export default ContactPage;